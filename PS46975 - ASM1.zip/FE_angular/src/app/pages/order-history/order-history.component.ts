import { Component, OnInit, inject } from '@angular/core';
import { CommonModule, CurrencyPipe, DatePipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-order-history',
  standalone: true,
  imports: [CommonModule, RouterModule, CurrencyPipe, DatePipe],
  template: `
    <div class="bg-gray-50 min-h-screen pb-[100px]">
      <!-- App Header -->
      <div class="p-4 bg-white flex items-center gap-3 sticky top-0 z-40 shadow-sm">
        <button (click)="goBack()" class="w-10 h-10 flex items-center justify-center text-gray-500 hover:text-black">
          <i class="fa-solid fa-arrow-left"></i>
        </button>
        <h1 class="font-bold text-lg uppercase tracking-wider text-gray-900">Lịch sử đơn hàng</h1>
      </div>

      <div *ngIf="loading" class="flex justify-center py-20">
        <i class="fa-solid fa-spinner fa-spin text-3xl text-gray-300"></i>
      </div>

      <div *ngIf="!loading && orders.length === 0" class="text-center py-20 text-gray-400">
        <i class="fa-solid fa-box-open text-5xl mb-4 text-gray-200"></i>
        <p class="text-sm font-bold uppercase tracking-widest text-gray-500 mb-6">Chưa có đơn hàng nào</p>
        <a routerLink="/catalog" class="inline-block px-8 py-3 bg-black text-white text-xs font-bold uppercase tracking-widest rounded-full hover:bg-gray-800 transition-colors">Mua sắm ngay</a>
      </div>

      <div *ngIf="!loading && orders.length > 0" class="p-4 space-y-4 animate-[fadeIn_0.3s_ease-out]">
        <div *ngFor="let order of orders" class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
          <!-- Order Header -->
          <div class="flex justify-between items-center mb-3 pb-3 border-b border-gray-50">
            <div>
              <span class="text-xs font-bold text-gray-500 block">Đơn hàng</span>
              <span class="text-sm font-black text-blue-600">{{ order._id }}</span>
            </div>
            <div class="text-right">
              <span class="inline-block px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider"
                    [ngClass]="getStatusClass(order.status)">
                {{ order.status }}
              </span>
              <p class="text-[10px] text-gray-400 mt-1">{{ order.createdAt | date:'dd/MM/yyyy HH:mm' }}</p>
            </div>
          </div>
          
          <!-- Order Items -->
          <div class="space-y-3 mb-3">
            <div *ngFor="let item of order.items" class="flex items-center gap-3">
              <div class="w-12 h-12 bg-gray-100 rounded-lg overflow-hidden shrink-0">
                <img [src]="item.product_variant_id?.product_id?.main_img || 'https://via.placeholder.com/150'" class="w-full h-full object-cover">
              </div>
              <div class="flex-1">
                <h4 class="text-xs font-bold text-gray-900 line-clamp-1">{{ item.product_variant_id?.product_id?.name || 'Sản phẩm' }}</h4>
                <p class="text-[10px] text-gray-500">Phân loại: {{ item.product_variant_id?.color || 'Mặc định' }} / {{ item.product_variant_id?.size || 'Mặc định' }}</p>
              </div>
              <div class="text-right shrink-0">
                <span class="text-xs font-bold">{{ item.price | currency:'VND':'symbol':'1.0-0' }}</span>
                <p class="text-[10px] text-gray-500">x{{ item.quantity }}</p>
              </div>
            </div>
          </div>
          
          <!-- Order Footer -->
          <div class="flex justify-between items-center pt-3 border-t border-gray-50">
            <span class="text-xs font-bold text-gray-500 uppercase tracking-widest">Tổng tiền</span>
            <span class="text-lg font-black text-gray-900">{{ order.total_amount | currency:'VND':'symbol':'1.0-0' }}</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class OrderHistoryComponent implements OnInit {
  orders: any[] = [];
  loading = true;
  private api = inject(ApiService);

  ngOnInit() {
    this.api.getMyOrders().subscribe({
      next: (res: any) => {
        this.orders = res.data || res || [];
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  getStatusClass(status: string): string {
    switch(status) {
      case 'PENDING': return 'bg-amber-100 text-amber-600';
      case 'CONFIRMED': return 'bg-blue-100 text-blue-600';
      case 'SHIPPING': return 'bg-indigo-100 text-indigo-600';
      case 'COMPLETED': return 'bg-green-100 text-green-600';
      case 'CANCELLED': return 'bg-red-100 text-red-600';
      default: return 'bg-gray-100 text-gray-600';
    }
  }

  goBack() {
    window.history.back();
  }
}
